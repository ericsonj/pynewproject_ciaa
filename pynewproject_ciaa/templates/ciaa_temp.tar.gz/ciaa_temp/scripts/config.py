FIRMWARE_V3_PATH    = "<%= firmware_path %>"                             
ARM_NONE_EABI_PATH  = "<%= arm_none_eabi_path %>"
